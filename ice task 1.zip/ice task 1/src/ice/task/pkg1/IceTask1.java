package ice.task.pkg1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import java.util.Scanner;

class Animal {
    int IDtag;
    String species;

    void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter ID tag: ");
        IDtag = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter species: ");
        species = scanner.nextLine();
    }

    void output() {
        System.out.println("ID tag: " + IDtag);
        System.out.println("Species: " + species);
    }
}

class Bird extends Animal {
    int colour;

    void inputBird() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter feather colour (1=grey, 2=white, 3=black): ");
        colour = scanner.nextInt();
    }

    void outputBird() {
        super.output();
        System.out.println("Feather colour: " + colour);
    }
}

class Reptile extends Animal {
    double bloodTemp;

    void inputReptile() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter blood temperature: ");
        bloodTemp = scanner.nextDouble();
    }

    void outputReptile() {
        super.output();
        System.out.println("Blood temperature: " + bloodTemp);
    }
}

public class IceTask1 {
    public static void main(String[] args) {
        Bird brd = new Bird();
        Reptile rept = new Reptile();

        // Input values
        brd.inputBird();
        rept.inputReptile();

        // Output values
        System.out.println("\nBird:");
        brd.outputBird();

        System.out.println("\nReptile:");
        rept.outputReptile();
    }
}

